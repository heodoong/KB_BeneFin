<template>
    <div>
        <h1>Authentic</h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="" scoped>

</style>