<template>
    <div>
        <h1>Personal Info</h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="" scoped>

</style>