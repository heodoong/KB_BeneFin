<template>
    <div>
        <h1>Join Clear</h1>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="" scoped>

</style>