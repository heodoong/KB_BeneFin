<template>
    <div class="main">
        <h1>BENEFIN</h1>
    </div>
</template>

<script>
    export default {
        name: 'Main',
    }
</script>

<style lang="" scoped>

</style>