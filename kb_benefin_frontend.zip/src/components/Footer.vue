<template>
    <div>

    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="" scoped>
* {
    box-sizing: border-box;
}

footer {
    border: 1px solid;
    height: 100px; 
}
</style>